
#include "ofMain.h"


class myClass{
public:
    //methods
    void setup();
    //you can define arguments to pass to a function here int x and y also declare in the cpp file for your class
    
    void draw(int x,int y);
    
    //properties
    ofColor color;

    
};



